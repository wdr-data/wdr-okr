import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

import pandas as pd
from datetime import datetime, timedelta


class QuintlyAPI:

    """The QuintlyAPI class can run queries on the Quinlty API

    :param client_id: The users client id for the Quintly API
    :param client_secret: The users secret for the Quintly API
    """

    base_url = 'https://api.quintly.com/v'
    version = '0.9'

    def __init__(self, client_id, client_secret, **kwargs):
        self._client_id = client_id
        self._client_secret = client_secret

        # Set default values for proxy credentials if they aren't set by the user
        self._proxies = kwargs.get('proxies', None)

        self._verify_ssl_certificate = kwargs.get('verify_ssl_certificate', True)
        self._profiles = None

        # Hide warnings in case certificate verification is disabled
        if not self._verify_ssl_certificate:
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

        self._request = QuintlyRequest(self)

        self._profiles = self._update_profiles()
        self._groups = self._update_groups()

    def _update_profiles(self):
        """Download the available profile tables

        :return: Returns a Pandas DataFrame containing information about the available profiles
        """

        profiles = self._request.send(method='list-profiles')

        if profiles is not None:
            self._profiles = profiles

        return pd.DataFrame(self._profiles)

    def _update_groups(self):
        """Download the available profile group tables

        :return: Returns a Pandas DataFrame containing the group id and name together with lists of the associated profile ids and names
        """

        # group_dict holds the group ids as keys and lists of the associated profile ids as values
        group_dict = {}

        # group_name_dict holds the group ids as keys an the associated group name as values
        group_name_dict = {}

        # profile_name_dict holds the profile id as keys and the associated profile name as values
        profile_name_dict = {}

        response = self._request.send(method='list-profiles')

        if response is not None:
            # for each profile, add profile to profile_name_dict and process the associated groups
            for profile in response:

                profile_id = profile['id']
                profile_name_dict[profile_id] = profile['name']

                # for each group add group to group_name_dict and update group_dict
                for group in profile['groups']:

                    group_id = group['id']
                    group_name_dict[group_id] = group['name']

                    if group_id in group_dict.keys():
                        group_dict[group_id].append(profile_id)
                    else:
                        group_dict[group_id] = [profile_id]

        # create groups matrix which contains the group and the corresponding profiles
        groups = []
        for group in group_dict.keys():
            profile_names = [profile_name_dict[x] for x in group_dict[group]]

            groups.append([group_name_dict[group], group, profile_names, group_dict[group]])

        return pd.DataFrame(groups, columns=['group_name', 'group_id', 'profile_names', 'profile_ids'])

    def __str__(self):
        return '%s object for the account %s' % (self.__class__.__name__, self._client_id,)

    def get_client_id(self):
        return self._client_id

    def get_client_secret(self):
        return self._client_secret

    def get_proxies(self):
        return self._proxies

    def get_verify_ssl_certificate(self):
        return self._verify_ssl_certificate

    def get_profiles(self):
        return self._profiles

    def get_groups(self):
        return self._groups

    def get_profile_ids_from_names(self, profile_names):
        """ Get the profile ids associated with the list of profile names
        :param profile_names: A list containing profile names
        :return: A list containing the associated profile ids
        """
        ids = self._profiles.loc[self._profiles['name'].isin(profile_names), 'id']

        return ids.values

    def get_profile_ids_from_group_name(self, group_name):
        """ Get the profile ids of a profile group
        :param group_name: The name of the group as string
        :return: A list containing the associated profile ids
        """
        res = []

        group = self._groups[self._groups['group_name'] == group_name]

        if len(group) > 0:
            res = group['profile_ids'].values[0]

        return res

    def _create_query(self, fields, table):
        """ Create a qql query based on a specified table and all requested fields
        :param fields: a list containig all requested fields
        :param table: a string which is the table from which the fields should be queried
        :return: a qql string
        """
        query = 'SELECT '
        query = query + ', '.join(fields)
        query = query + ' FROM '
        query = query + table

        return query

    def _create_date_stack(self, start_date, end_date, split_days):
        """ Splits a time range into chunks of specified length
        :param start_date: datetime object
        :param end_date: datetime object
        :return: A matrix where each row contains start and end date of the chunks as datetime objects

        """
        dates_stack = []
        curr_date = start_date

        while (curr_date + timedelta(days=split_days)) < end_date:
            dates_stack.append([curr_date, curr_date + timedelta(days=split_days - 1)])
            curr_date = curr_date + timedelta(days=split_days)

        dates_stack.append([curr_date, end_date])

        return dates_stack

    def run_query(self, profiles, table, fields, start_date, end_date, interval='daily', split_profiles=False,
                  split_days=0, print_logs=False, raw=False):
        """Queries the Quintly API and returns the result as Pandas DataFrame

        :param profiles: a list of all profiles for which the fields should be queried
        :param table: a string which is the table which should be queried
        :param fields: a list of all fields which should be queries
        :param start_date: a datetime object
        :param end_date: a datetime object
        :param interval: a string which is the aggregation level: 'daily', 'weekly', 'monthly'
        :param split_profiles: a boolean. If True, multiple queries for each profile will be conducted
        :param split_days: a int. If bigger than zero, then multiple queries will be conducted which split the time range into the specified amount of days
        :param print_logs: a boolean. If True, for each query a log will be printed
        :return: Returns a Pandas DataFrame
        """

        # Create the query
        query = self._create_query(fields, table)

        # This query makes a request for each entry in the dates_stack and the profiles_stack.
        # If e.g. if three profiles are provided and the time range could be split into four chunks, then
        # splitting by profiles results in three queries, splitting by time results in four queries and
        # splitting by both results in 12 queries.

        # Create request structure
        if split_days == 0:
            dates_stack = [[start_date, end_date]]
        else:
            dates_stack = self._create_date_stack(start_date, end_date, split_days)

        if split_profiles:
            profiles_stack = [[profile] for profile in profiles]
        else:
            profiles_stack = [profiles]

        response = []

        # Run the queries according to the specified request structure
        for dates in dates_stack:
            for prof in profiles_stack:

                if print_logs:
                    print('Querying profiles', ','.join(list(map(str, prof))), 'for time range', dates[0], '-', dates[1])

                payload = {
                    'qqlQuery': query,
                    'startTime': dates[0],
                    'endTime': dates[1],
                    'profileIds': ','.join(list(map(str, prof))),
                    'interval': interval
                }

                try:
                    response.extend(self._request.send(method='qql', params=payload))
                except Exception as err:
                    print('Error during request for ids', payload['profileIds'], 'for time range ', payload['startTime'], '-', payload['endTime'])
                    print('Message:', err)
        if raw:
            return(response)
        else:
            return(pd.DataFrame(response))


class QuintlyRequest:
    """A helper class for the class QuintlyAPI
    """

    def __init__(self, quintly_api, **kwargs):
        self._quintly_api = quintly_api
        self._method = kwargs.get('method', 'list-profiles')
        self._version = kwargs.get('version', QuintlyAPI.version)
        self._params = kwargs.get('params', {})
        self._payload = None
        self._response = None

    def __str__(self):
        return '%s object for method %s' % (self.__class__.__name__, self._method)

    def send(self, **kwargs): # argument must be a dictionary
        self._version = kwargs.get('version', self._version)
        self._method = kwargs.get('method', self._method)
        self._params = kwargs.get('params', self._params)
        self._response = None

        if type(self._params) is not dict:
            raise RuntimeError('Wrong argument, params has to be a dict')

        response = requests.get(QuintlyAPI.base_url + self._version + '/' + self._method,
                                auth=(self._quintly_api.get_client_id(), self._quintly_api.get_client_secret()),
                                params=self._params,
                                verify=self._quintly_api.get_verify_ssl_certificate(),
                                proxies=self._quintly_api.get_proxies())

        response.raise_for_status()
        response = response.json()

        if response['success']:
            self._response = response['data']
        else:
            self._response = None

        return self._response

