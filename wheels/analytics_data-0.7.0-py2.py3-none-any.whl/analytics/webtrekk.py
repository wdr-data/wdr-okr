#! Python3

import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning


class WebtrekkAPI:
    base_url = 'https://report2.webtrekk.de/cgi-bin/wt/JSONRPC.cgi'
    version = '1.1'

    def __init__(self,account_id, username, password, **kwargs):
        self._account_id = account_id
        self._username = username
        self._password = password

        # Set default values for proxy credentials if they aren't set by the user
        self._proxies = kwargs.get('proxies', None)

        self._verify_ssl_certificate = kwargs.get('verify_ssl_certificate', True)

        # Hide warnings in case certificate verification is disabled
        if not self._verify_ssl_certificate:
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

        self._connection_token = None
        self._account_list = None
        self._report_list = None
        self._analysis_objects_and_metrics = None
        self._dynamic_time_intervals = None

        self._request = WebtrekkRequest(self)

        # Start session by requesting a token from API
        self._login()

    def _login(self):
        response = self._request.send(method='login',
                                      params={
                                          'login': self.get_username(),
                                          'pass': self.get_password(),
                                          'customerId': self.get_account_id(),
                                          'language': 'en'
                                      })

        if response is not None:
            self._connection_token = response
            return True
        else:
            self._connection_token = None
            return False

    def _logout(self):
        response = self._request.send(method='logout')

        if response is not None:
            if response == 1:
                self._connection_token = None
                return True
            else:
                return False
        else:
            return False

    def __str__(self):
        return '%s object for the account %s using the username %s' % (self.__class__.__name__,
                                                                       self._account_id,
                                                                       self._username)

    def get_connection_token(self):
        return self._connection_token

    def get_verify_ssl_certificate(self):
        return self._verify_ssl_certificate

    def get_account_id(self):
        return self._account_id

    def get_username(self):
        return self._username

    def get_password(self):
        return self._password

    def get_proxies(self):
        return self._proxies

    def get_account_list(self):
        return self._request.send(method='getAccountList')

    def get_report_list(self):
        return self._request.send(method='getCustomReportsList')

    def get_analysis_objects_and_metrics(self):
        return self._request.send(method='getAnalysisObjectsAndMetricsList')

    def get_dynamic_time_intervals(self):
        return self._request.send(method='getDynamicTimeIntervalList')

    def test_connection(self):
        response = self._request.send(method='getConnectionTest')

        if response is None:
            return False
        elif response == 'Connection successful':
            return True
        else:
            return False

    def get_analysis_data(self, analysis_config):

        if type(analysis_config) is dict:
            response = self._request.send(method='getAnalysisData',
                                          params={'analysisConfig': analysis_config})

            if 'analysisWarnings' in response:
                print(response['analysisWarnings'])

            return response
        else:
            raise RuntimeError('argument analysis_config must be a dict')

    def get_report_data(self, report_name, time_start, time_stop, footer_identifier='-'):
        response = self._request.send(method='getReportData',
                                      params={
                                          'report_name': report_name,
                                          'time_start': time_start,
                                          'time_stop': time_stop,
                                          'footerIdentifier': footer_identifier
                                      })
        return response

    def export_metadata(self, start_row, end_row, type, title=None, rows_without_data=0):
        response = self._request.send(method='exportData',
                                      params={
                                          'startRow': start_row,
                                          'endRow': end_row,
                                          'type': type,
                                          'title': title,
                                          'rowsWithoutData': rows_without_data
                                      })
        return response

    def import_metadata(self, upload_data, upload_type):
        response = self._request.send(method='importData',
                                      params={
                                          'uploadData': upload_data,
                                          'uploadType': upload_type
                                      })
        return response

class WebtrekkRequest:

    def __init__(self, webtrekk_api, **kwargs):
        self._webtrekk_api = webtrekk_api

        self._version = kwargs.get('version', WebtrekkAPI.version)
        self._method = kwargs.get('method', 'getConnectionTest')
        self._params = kwargs.get('params', {})

        self._payload = None
        self._response = None

    def __str__(self):
        return '%s object for method %s' % (self.__class__.__name__, self._method)

    def send(self, **kwargs):  # argument must be a dictionary
        self._version = kwargs.get('version', self._version)
        self._method = kwargs.get('method', self._method)
        self._params = kwargs.get('params', self._params)
        self._response = None

        if type(self._params) is not dict:
            raise RuntimeError('Wrong argument, params has to be a dictionary')

        if self._webtrekk_api.get_connection_token() is not None:
            self._params['token'] = self._webtrekk_api.get_connection_token()

        self._payload = json.dumps({
            'version': self._version,
            'method': self._method,
            'params': self._params})

        request_response = requests.post(WebtrekkAPI.base_url,
                                         data=self._payload,
                                         verify=self._webtrekk_api.get_verify_ssl_certificate(),
                                         proxies=self._webtrekk_api.get_proxies())

        request_response.raise_for_status()
        response = request_response.json()

        if 'error' in response:
            print(response['error']['name'] + ' - ' +
                  str(response['error']['code']) + ' - ' +
                  response['error']['message'])

            self._response = None

        elif 'result' not in response:
            self._response = None
            print('no result data found in response')

        else:
            self._response = response['result']

        return self._response
