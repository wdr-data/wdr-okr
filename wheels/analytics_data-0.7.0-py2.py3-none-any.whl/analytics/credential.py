import keyring
import getpass


class CredentialHelper:
    VALUE_TYPE_TEXT = 0
    VALUE_TYPE_PASSWORD = 1
    _keyring = keyring.get_keyring()

    def __init__(self, configuration):
        self._configuration = configuration

    def request_credentials(self):
        for item in self._configuration:
            self.get_credential(item['system'], item['key'])

    def get_credential(self, system, key):
        value = CredentialHelper._keyring.get_password(system, key)

        configuration_item = next((item for item in self._configuration if item['system'] == system and  item['key'] == key), None)

        if value is None:
            print('Please enter ' + configuration_item['label'] + ':')

            if configuration_item['value_type'] == CredentialHelper.VALUE_TYPE_TEXT:
                value = input()
            elif configuration_item['value_type'] == CredentialHelper.VALUE_TYPE_PASSWORD:
                value = getpass.getpass()
            else:
                raise('Invalid value type ' + configuration_item['value_type'] + ' for key ' + key)
                value = None

        CredentialHelper._keyring.set_password(system, key, value)

        return value

    def reset_credentials(self):
        for item in self._configuration:
            CredentialHelper._keyring.delete_password(item['system'], item['key'])